﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SAA_Task_04
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Random rnd = new Random();
            int Health_lihs = rnd.Next(450, 700);
            int Damage_lihs;
            int Health_player = rnd.Next(200, 500);
            int Mana_player = rnd.Next(100, 400);
            bool Start_Game = true;
            string castspell;

            Console.WriteLine("Лич  атакует приготовьтесь к бою\n \nВыберите заклинания для атаки или лечения: \n" +
                " Fireball - Огненый шар наносит 50 урона, отнимает 15 единиц маны.\n" +
                " Healing - Востанавливает игроку  20 здоровья, отнимает 30 единиц маны.\n" +
                " Lightningbolt - Удар молнией наносит 100 урона, отнимает 50 единиц маны.\n" +
                " Rockrain - Каменный дождь  наносит 35 урона каждую секунду, отнимает 120 единиц маны.\n");

            while (Start_Game)
            {
                Damage_lihs = rnd.Next(35, 90);
                Console.WriteLine($"\nСтатистика Лич: \n Здоровье: {Health_lihs} , Урон: {Damage_lihs} \n\nСтатистика игрока: \n Здоровье: {Health_player} , Мана: {Mana_player} \n");
                Console.Write("Введите заклинание: ");
                castspell = Console.ReadLine();
                if (Mana_player <= 15)
                {
                    Start_Game = false;
                    Console.WriteLine("\nИгра окончена, недостаточно маны для продолжения битвы");                   
                }
                else if (Health_lihs <= 0)
                {
                    Start_Game = false;
                    Console.WriteLine("\nЛич погиб");                   
                }
                else if (Health_player <= 0)
                {
                    Start_Game = false;
                    Console.WriteLine("\nИгрок погиб");                    
                }
                else
                {                    
                    switch (castspell)
                    {
                        case "fireball":
                            if (Mana_player >= 15)
                            {
                                Health_lihs -= 40;
                                Console.WriteLine("\nЛич потерял 50 единиц здоровья");
                                Mana_player -= 15;
                                Health_player -= Damage_lihs;
                                Console.Write($"\nЛич атаковал исушением игрок потерял {Damage_lihs} здоровья\n");   
                            }
                            else
                            {
                                Console.WriteLine("\nУ вас не достаточно маны!");
                            }
                            break;
                        case "healing":
                            if (Mana_player >= 30)
                            {
                                Mana_player -= 30;
                                Health_player += 20;
                                Console.WriteLine($"\nВаше текущее здоровье равно: {Health_player}");
                            }
                            else if (Health_player >= 349)
                            {
                                Console.WriteLine("\nУ вас полный запас здоровья");
                            }
                            else
                            {
                                Console.WriteLine("\nУ вас не достаточно маны!");
                            }
                            break;
                        case "lightningbolt":
                            if (Mana_player >= 50)
                            {
                                Console.WriteLine("\nЛич потерял 100 единиц здоровья");
                                Health_lihs -= 100;
                                Mana_player -= 50;
                                Health_player -= Damage_lihs;
                                Console.Write($"\nЛич атаковал ззаклинанием Отравление которое нанесло {Damage_lihs} урона\n");
                            }
                            else
                            {
                                Console.WriteLine("\nУ вас не достаточно маны!");
                            }
                            break;
                        case "rockrain":
                            if (Mana_player >= 120)
                            {
                                int rockrain = 0;
                                for (int i = 1; i < 6; i++)
                                {
                                    rockrain += 35;
                                    Thread.Sleep(1000);
                                    Health_lihs -= 35;
                                    Console.Write($"Атака каменным дождем наносит урон Личу {rockrain}:  \nПродолжительность атаки {i} секунды");
                                    Console.WriteLine(); 
                                }                              
                                    Console.WriteLine("\nЛич потерял после атаки 175 единиц здоровья");
                                Mana_player -= 40;
                            }
                            else
                            {
                                Console.WriteLine("\nУ вас не достаточно маны!");
                            }
                            break;
                        default:
                            Console.WriteLine($"\nВам незнакомо {castspell} это заклинание");
                            break;
                    }
                    
                }
            }
        }
    }
}
