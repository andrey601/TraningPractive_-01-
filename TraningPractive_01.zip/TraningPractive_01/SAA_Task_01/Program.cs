﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAA_Task_01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Сколько у вас золота в наличие ?");
            int Gold;
            while (true)
            {
                try
                {
                    Gold = int.Parse(Console.ReadLine());
                    if (Gold < 0)
                    {
                        Console.WriteLine("У вас не может быть число с минусом ");
                    }
                    else break;
                }
                catch
                {
                    Console.WriteLine("Извените я вас не могу понять сделайте ещё раз");
                }
            }

            while (true)
            {
                if (!int.TryParse(Console.ReadLine(), out var a))
                {
                    Console.WriteLine("Пишите только цифры!");
                    continue;
                }

                Gold = Convert.ToInt32(Console.ReadLine());
                int Crystal = 5;
                Console.WriteLine("Вы можете купить максимум " + Crystal + " кристалов по цене " + Crystal + " за штуку.");
                Console.WriteLine("Сколько хотите купить кристалов?");
                int Buy;
                Buy = Convert.ToInt32(Console.ReadLine());
                while (true)
                {
                    try
                    {
                        Buy = int.Parse(Console.ReadLine());
                        if (Buy > Gold)
                        {
                            Console.WriteLine("У вас не может быть количество золота с отрицательном знаком ");
                        }
                        else break;
                    }
                    catch
                    {
                        Console.WriteLine("Извените я вас не могу понять сделайте ещё раз");
                    }



                }
                int Max_Crystal = Gold / Crystal;

                Console.WriteLine("Вы купили " + Buy + " кристалов. У вас  в наличие осталось " + (Gold - Buy * Crystal) + " золота");


                Console.ReadKey();

            }
        }
    }
}
