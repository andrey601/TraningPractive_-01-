﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAA_Task_02
{
    class Program
    {
        static void Main(string[] args)
        {

Console.WriteLine("Введите число от 1 до 9 или EXIT чтоб програма завершила свою работу");
            string b = "";
            do
            {
                b = Console.ReadLine();
                switch (b)
                {

                    case "1":
                        Console.WriteLine("Один");
                        break;
                    case "2":
                        Console.WriteLine("Два");
                        break;
                    case "3":
                        Console.WriteLine("Три");
                        break;
                    case "4":
                        Console.WriteLine("Четыре");
                        break;
                    case "5":
                        Console.WriteLine("Пять");
                        break;
                    case "6":
                        Console.WriteLine("Шесть");
                        break;
                    case "7":
                        Console.WriteLine("Семь");
                        break;
                    case "8":
                        Console.WriteLine("Восемь");
                        break;
                    case "9":
                        Console.WriteLine("Девять");
                        break;
                    default:
                        Console.WriteLine("Вам нужно вести от 1 до 9");
                        break;
                }
            } while (b != "EXIT");
            Console.WriteLine("Программа закончена");
            Console.ReadKey();
        }
        
    }
}
