﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAA_Task_07
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите количество массива: ");
            int a = Convert.ToInt32(Console.ReadLine());
            int[] mass = new int[a];
            Random rnd = new Random();
            for (int b = 0; b < a; b++)
            {
                mass[b] = rnd.Next(0, 100);
            }
            Console.WriteLine("Изначальный: " + string.Join(" ", mass));
            Shuffle(mass);
            Console.WriteLine("Ставший: " + string.Join(" ", mass));
            Console.ReadKey();
        }
        static void Shuffle<T>(IList<T> arr)
        {
            Random random = new Random();
            for (int b = 0; b < 100; b++)
            {
                var rand1 = random.Next(0, arr.Count());
                var rand2 = random.Next(0, arr.Count());
                var temp = arr[rand1];
                arr[rand1] = arr[rand2];
                arr[rand2] = temp;
            }
        }
    }
}

