﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SAA_Task_03
{
    class Program
    {
        static void Main(string[] args)
        {
            string Password = "I am programist";
            string Enter_password;
            int Counter = 3;
            while (Counter > 0)
            {
                Console.Write("Введите пароль для доступа к сообщению у вас есть 3 попытки: ");
                Enter_password = Console.ReadLine();
                if (Password == Enter_password)
                {
                    Console.WriteLine("Ваше секретеное сообщение: Я у мамы программист !");
                }
                else
                {
                    Counter--;
                    Console.WriteLine("Вы ввели неправильный пароль у вас осталось: " + Counter + " попытки что ввести правильный пароль");

                }
            }
            Console.WriteLine("Попробуйте снова через 12 часа");



        }
    }
}
